# Running the GPU test yourself, step by step

> **PROPRIETARY - EVALUATION AND SIMULATION USE ONLY.** Copyright (c) 2026 The Omni-Compass LLC. This is not open-source software (`SPDX-License-Identifier: LicenseRef-OmniCompass-Evaluation-1.0`). Any commercial use, commercialization, monetization, production use, redistribution, hosted service or incorporation into a product requires a signed, paid **Omni-Compass Enterprise License** from The Omni-Compass LLC. Protected by copyright, patents and trademarks: Patent applications, copyright registrations and trademark applications covering the Omni-Compass engine, its mathematics and its software have been filed in the United States by The Omni-Compass LLC. See [`LICENSE`](../LICENSE).

There are three ways to get real-machine numbers:
- **Your own tower:** a machine you control, with a smart plug measuring the whole machine at the wall (section A).
- **GitHub's GPU machines:** they run the test from the repository with one click (section B).
- **A rented cloud GPU:** sections 1 to 6.

## A. Your own tower, measured at the wall

You need:
- an NVIDIA graphics card (a GeForce RTX works);
- Linux on that machine (a spare drive or a USB boot is fine);
- a smart plug that reports watts, for example a Shelly Plus Plug or any plug running Tasmota, which cost about
  $20 to $30.

Plug the tower into the smart plug, and connect the plug to your home Wi-Fi with its own app. Note its IP address,
shown in the app or on your router's device list. Then on the tower:

```bash
python3 tools/wall_meter.py shelly2:192.168.1.50 --once        # prints the tower's watts right now
sudo WALL_METER=shelly2:192.168.1.50 bash scripts/gpu_paired.sh                  # trial run
sudo WALL_METER=shelly2:192.168.1.50 PHASE=confirm bash scripts/gpu_paired.sh    # the real test
```

Use `shelly1:` for older Shelly plugs and `tasmota:` for Tasmota plugs. The table then adds whole-machine energy at
the wall and requests served per wall kilojoule. The plug is read by the test only; Omni never sees it, so its number
is independent of Omni.

## B. GitHub's own GPU machines

1. **One-time setup, by an owner of the Omni-Compass organisation on GitHub:**
   1. Go to **Settings → Actions → Runners → New runner → New GitHub-hosted runner**.
   2. Choose the image **NVIDIA GPU-Optimized Image for Linux** and a GPU size.
   3. Name its label `gpu-t4`, or set the repository variable `GPU_RUNNER` to the label you chose.

   GPU runners are billed per minute on paid plans.
2. **To run:** go to **Actions → gpu-bench → Run workflow**, then choose `smoke` or `confirm`.
3. **Results:** each repetition runs on its own GPU machine. The results are pooled into one table, shown on the run's
   summary page, and every raw file is committed back to the branch under `results/gpu/github-<run id>/`.

If GitHub's machines don't allow changing the GPU power limit, the job stops in its first minute and says so.

## C. A rented cloud GPU

This costs roughly $10 to $25 in rented GPU time. You type a
handful of commands; the machine does the rest.

## 1. Rent the right kind of machine

The test changes the GPU's power limit, so you need a machine where you are the full administrator of the GPU:

- **Use a virtual machine (VM) or a bare-metal server.** Lambda Cloud "on-demand instances" are VMs; so are the GPU
  instances on AWS, Google Cloud and Azure.
- **Avoid "container" or "pod" rentals.** Their GPUs usually block power-limit changes. This is common on the cheapest
  per-hour marketplaces.
- **Any single NVIDIA data-center GPU works:** A10, L4, A100, H100, L40S. One GPU is enough.
- **Choose an image that already has PyTorch.** On Lambda that is the default "Lambda Stack" image.

You don't have to guess whether a machine allows it. In its first minute the test checks, and stops with *"cannot set
the power limit (run as root)"* if the machine doesn't allow it. If you see that, shut the machine down (you pay only
for the minutes used) and rent a different kind.

## 2. Connect to it

The rental site shows a command like `ssh ubuntu@123.45.67.89`. Paste it into Terminal (Mac) or PowerShell (Windows).

## 3. Get the code

The repository is private, so GitHub needs a key:

1. On github.com go to **Settings → Developer settings → Personal access tokens → Fine-grained tokens**.
2. Create a token with **read-only** access to this one repository. Copy it.

Then on the rented machine:

```bash
git clone -b claude/kubernetes-clusters-docker-stack-gp26ve https://<YOUR-GITHUB-NAME>:<TOKEN>@github.com/The-Omni-Compass-LLC/The-Omni-Compass omni
cd omni
pip install numpy          # PyTorch is already on the machine
nvidia-smi                 # should show your GPU
```

## 4. The trial run (about 40 minutes)

This checks that everything works on your machine. It is never published.

```bash
sudo REPS=2 DURATION=300 bash scripts/gpu_paired.sh
```

At the end it prints a table. What matters here:
- It doesn't say **INVALID**.
- The *Omni governs* column shows power-limit writes.
- The watch arm shows zero writes.

## 5. The real test (about 6 hours)

The code is frozen, with 10 repetitions, exactly as fixed in `docs/GPU_PREREGISTRATION.md`. Don't change anything
between the trial and this.

```bash
sudo PHASE=confirm nohup bash scripts/gpu_paired.sh > confirm.log 2>&1 &
```

`nohup ... &` keeps it running if your connection drops. You can close the window and come back. To check on it:

```bash
tail -5 confirm.log
```

## 6. Bring the results back

When `confirm.log` ends with the table:

```bash
sudo tar czf gpu_results.tgz results/gpu
```

Then, from your own computer (a new Terminal window, not the rented machine):

```bash
scp ubuntu@123.45.67.89:omni/gpu_results.tgz .
```

Send that file to Claude, or keep it. It holds every raw reading, the table, the verdict and checksums.

**Then shut the rented machine down** on the rental site, so the billing stops.

## Before any machine: the simulated card

`python3 tools/gpu_physics_sim.py --out results/gpu/sim/after` runs Omni's own GPU governor, with its current
settings, against a modelled card for 10 paired repetitions in about two minutes. No GPU is needed. Every number it
prints comes from the card model, not from a meter, so it is a preview of what the governor does and never the result.
`results/gpu/sim/before` holds the same run with the settings before the share floor and busy gate were added.

## What you will get

A table from the GPU's own power meter:
- native against Omni watching only, and native against Omni governing;
- the preregistered primary result: work per energy, in requests served per kilojoule, with its 95% interval.

It ends with one verdict line, one of:
- **better, proven**;
- **worse, proven**;
- **not proven**;
- **better on energy, fails the service guardrail**.

Whatever it says is the answer, and it is the first number in this project that Omni-Compass's own code did not
compute.
